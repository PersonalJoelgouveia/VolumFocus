import { useState } from 'react';
import { useAlunoStore } from '../../store/useAlunoStore';
import { usePhysicalAssessments } from '../../hooks/usePhysicalAssessments';
import type { AssessmentProtocol, PhysicalAssessment, SkinfoldSet } from '../../types/assessment';
import { SKINFOLD_SITES, type SkinfoldAssessmentPayload } from '../../utils/pollock7';
import { dateInputParaISO } from '../../utils/timelineDate';
import { derivarRCQDeCircunferencias } from '../../utils/onlineAssessment';
import { SkinfoldAssessmentForm } from './SkinfoldAssessmentForm';
import { BioimpedanceAssessmentForm, type BioimpedanceAssessmentPayload } from './BioimpedanceAssessmentForm';
import { AssessmentTimeline } from './AssessmentTimeline';
import { CompareAssessmentsModal } from './CompareAssessmentsModal';
import { OnlineAssessmentForm } from './OnlineAssessmentForm';
import { OnlineReview } from './OnlineReview';
import { PhysicalAssessmentDashboard } from '../../views/PhysicalAssessmentDashboard';
import { useAuthStore } from '../../store/useAuthStore';
import './ClientesView.css';
import './AvaliacaoFisicaModal.css';

/** Protocolos do seletor — chave já é o `AssessmentProtocol` do domínio
 *  (types/assessment.ts). Novo protocolo = nova entrada aqui; nada mais
 *  no componente precisa mudar. */
const PROTOCOL_OPTIONS: Array<{
  key: AssessmentProtocol;
  icon: string;
  title: string;
  subtitle: string;
  comingSoon?: boolean;
}> = [
  { key: 'skinfold', icon: '📏', title: 'Dobras', subtitle: 'Avaliação corporal através de medidas manuais' },
  { key: 'bioimpedance', icon: '⚡', title: 'Bioimpedância', subtitle: 'Dados de composição corporal obtidos por bioimpedância' },
  { key: 'online', icon: '☁️', title: 'Online', subtitle: 'Autoavaliação remota preenchida pelo aluno' },
  { key: 'custom', icon: '🛠️', title: 'Personalizada', subtitle: 'Modelo de avaliação adaptável', comingSoon: true },
];

interface AvaliacaoFisicaModalProps {
  alunoId: string;
  onClose: () => void;
  /** Disparado ao escolher um protocolo sem formulário próprio ainda
   *  (Bioimpedância) e sem "Em breve" (Online/Personalizada). Dobras é
   *  tratado internamente, abrindo o SkinfoldAssessmentForm. */
  onSelectProtocol?: (protocol: AssessmentProtocol) => void;
  /** Quando true, oculta ações de escrita — mesma view, uso pelo Aluno.
   *  Bloqueio real de escrita já vem de `canWrite` (role), isto é só UX. */
  readOnly?: boolean;
}

/**
 * Escopo inicial do módulo "Avaliação Física": resumo da última avaliação +
 * atalhos para histórico/evolução e nova avaliação. Sem acoplamento ao papel
 * de quem visualiza — lê apenas de `useAlunoStore` por `alunoId`, mesma
 * fonte que servirá o app do Aluno mais adiante.
 */
export function AvaliacaoFisicaModal({
  alunoId,
  onClose,
  onSelectProtocol,
  readOnly = false,
}: AvaliacaoFisicaModalProps) {
  const assessments = useAlunoStore((s) => s.getAvaliacoes(alunoId));
  const temHistorico = assessments.length > 0;
  const podeComparar = assessments.length >= 2;
  const { loading, error, retry, canWrite, podeEnviarOnline, salvar, editar, remover } = usePhysicalAssessments(alunoId);
  const personalEmail = useAuthStore((s) => s.user?.email);

  const [step, setStep] = useState<
    'resumo' | 'protocolo' | 'skinfold-form' | 'bioimpedance-form' | 'online-form' | 'revisar-online' | 'evolucao' | 'comparar'
  >('resumo');
  const [modoComparar, setModoComparar] = useState<'primeira-atual' | 'anterior-atual'>('primeira-atual');
  const [revisandoId, setRevisandoId] = useState<string | null>(null);
  /** Presente = os formulários de Dobras/Bioimpedância/Online abrem em
   *  modo edição, pré-preenchidos, e o save vira `editar()` em vez de
   *  `salvar()`. Só o Personal chega aqui (botão "Editar" na timeline). */
  const [editando, setEditando] = useState<PhysicalAssessment | null>(null);

  function handleEditar(assessment: PhysicalAssessment) {
    setEditando(assessment);
    if (assessment.protocol === 'skinfold') setStep('skinfold-form');
    else if (assessment.protocol === 'bioimpedance') setStep('bioimpedance-form');
    else if (assessment.protocol === 'online') setStep('online-form');
  }

  function handleCancelarEdicao() {
    setEditando(null);
    setStep('resumo');
  }

  function handleSelectProtocol(protocol: AssessmentProtocol, comingSoon?: boolean) {
    if (comingSoon) return;
    if (protocol === 'skinfold') {
      setStep('skinfold-form');
      return;
    }
    if (protocol === 'bioimpedance') {
      setStep('bioimpedance-form');
      return;
    }
    if (protocol === 'online') {
      setStep('online-form');
      return;
    }
    if (onSelectProtocol) {
      onSelectProtocol(protocol);
    } else {
      console.log('[AvaliacaoFisicaModal] Protocolo selecionado — placeholder', { alunoId, protocol });
    }
  }

  async function handleSaveSkinfold(payload: SkinfoldAssessmentPayload) {
    const now = new Date().toISOString();
    const imc = payload.pesoKg / (payload.alturaCm / 100) ** 2;

    const skinfolds = SKINFOLD_SITES.reduce((acc, site) => {
      const t = payload.triples[site];
      acc[site] = { measurement1: t.m1, measurement2: t.m2, measurement3: t.m3, average: t.media };
      return acc;
    }, {} as SkinfoldSet);

    const assessment: PhysicalAssessment = {
      id: payload.assessmentId,
      alunoId,
      date: dateInputParaISO(payload.data),
      protocol: 'skinfold',
      anthropometry: { peso: payload.pesoKg, altura: payload.alturaCm, imc, sexoBiologico: payload.sexo, idadeAnos: payload.idade },
      circumferences: payload.circunferencias,
      skinfolds,
      results: {
        percentualGordura: payload.resultado.percentualGordura,
        percentualMassaGorda: payload.resultado.percentualGordura,
        massaGordaKg: payload.resultado.massaGordaKg,
        percentualMassaLegra: payload.resultado.percentualMassaMagra,
        massaMagraKg: payload.resultado.massaMagraKg,
        // RCQ derivada das circunferências desta avaliação (cintura/quadril),
        // quando ambas foram medidas — protocolo de cálculo já existente,
        // só agora também aplicado fora do protocolo Online.
        relacaoCinturaQuadril: derivarRCQDeCircunferencias(payload.circunferencias),
      },
      createdAt: editando?.createdAt ?? now,
      updatedAt: now,
    };

    if (editando) {
      await editar(assessment.id, assessment);
    } else {
      await salvar(assessment);
    }
    setEditando(null);
    setStep('resumo');
  }

  async function handleSaveBioimpedance(payload: BioimpedanceAssessmentPayload) {
    const now = new Date().toISOString();

    // Bioimpedância não mede dobras — grava zeros pra satisfazer o formato
    // do SkinfoldSet, e buildSeriesDobras/compararAvaliacoes já filtram por
    // `protocol === 'skinfold'`, então esses zeros nunca entram em gráfico
    // nem em comparação.
    const skinfolds = SKINFOLD_SITES.reduce((acc, site) => {
      acc[site] = { measurement1: 0, measurement2: 0, measurement3: 0, average: 0 };
      return acc;
    }, {} as SkinfoldSet);

    const assessment: PhysicalAssessment = {
      id: payload.assessmentId,
      alunoId,
      date: dateInputParaISO(payload.data),
      protocol: 'bioimpedance',
      anthropometry: { peso: payload.pesoKg, altura: payload.alturaCm, imc: payload.resultado.imc },
      circumferences: payload.circunferencias,
      skinfolds,
      results: {
        percentualGordura: payload.percentualGordura,
        percentualMassaGorda: payload.percentualGordura,
        massaGordaKg: payload.resultado.massaGordaKg,
        percentualMassaLegra: payload.percentualMassaMagra,
        massaMagraKg: payload.resultado.massaMagraKg,
        gorduraVisceral: payload.gorduraVisceral,
        metabolismoBasal: payload.metabolismoBasal,
        relacaoCinturaQuadril: derivarRCQDeCircunferencias(payload.circunferencias),
      },
      createdAt: editando?.createdAt ?? now,
      updatedAt: now,
    };

    if (editando) {
      await editar(assessment.id, assessment);
    } else {
      await salvar(assessment);
    }
    setEditando(null);
    setStep('resumo');
  }

  if (step === 'skinfold-form') {
    return (
      <SkinfoldAssessmentForm
        alunoId={alunoId}
        onCancel={editando ? handleCancelarEdicao : () => setStep('protocolo')}
        onSave={handleSaveSkinfold}
        assessmentExistente={editando ?? undefined}
      />
    );
  }

  if (step === 'bioimpedance-form') {
    return (
      <BioimpedanceAssessmentForm
        alunoId={alunoId}
        onCancel={editando ? handleCancelarEdicao : () => setStep('protocolo')}
        onSave={handleSaveBioimpedance}
        assessmentExistente={editando ?? undefined}
      />
    );
  }

  if (step === 'online-form') {
    return (
      <OnlineAssessmentForm
        alunoId={alunoId}
        onCancel={editando ? handleCancelarEdicao : () => setStep('resumo')}
        assessmentExistente={editando ?? undefined}
        onSave={async (assessment) => {
          const ok = editando ? await editar(assessment.id, assessment) : await salvar(assessment);
          if (ok) {
            setEditando(null);
            setStep('resumo');
          }
          return ok;
        }}
      />
    );
  }

  if (step === 'revisar-online' && revisandoId) {
    const alvo = assessments.find((a) => a.id === revisandoId);
    if (!alvo) {
      setStep('resumo');
      return null;
    }
    return (
      <div className="modal-backdrop" onClick={() => setStep('resumo')}>
        <div className="cli-detail-panel af-panel" onClick={(e) => e.stopPropagation()}>
          <div className="modal-header">
            <h2 style={{ marginBottom: 0 }}>Avaliação Física</h2>
            <button className="modal-close" onClick={() => setStep('resumo')} aria-label="Fechar">
              ×
            </button>
          </div>
          <OnlineReview
            assessment={alvo}
            mode="personal"
            onMarcarRevisada={async (nota) => {
              await editar(alvo.id, {
                status: 'revisada',
                review: {
                  reviewedBy: personalEmail ?? 'Personal',
                  reviewedAt: new Date().toISOString(),
                  reviewNote: nota || undefined,
                },
              });
              setStep('resumo');
            }}
          />
        </div>
      </div>
    );
  }

  if (step === 'evolucao') {
    return (
      <PhysicalAssessmentDashboard
        alunoId={alunoId}
        onClose={() => setStep('resumo')}
        onComparar={() => {
          setModoComparar('anterior-atual');
          setStep('comparar');
        }}
      />
    );
  }

  if (step === 'comparar') {
    return <CompareAssessmentsModal alunoId={alunoId} onClose={() => setStep('resumo')} defaultMode={modoComparar} />;
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="cli-detail-panel af-panel" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          {step === 'protocolo' ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <button className="af-back-btn" onClick={() => setStep('resumo')} aria-label="Voltar">
                ‹
              </button>
              <h2 style={{ marginBottom: 0 }}>Escolha o protocolo</h2>
            </div>
          ) : (
            <h2 style={{ marginBottom: 0 }}>Avaliação Física</h2>
          )}
          <button className="modal-close" onClick={onClose} aria-label="Fechar">
            ×
          </button>
        </div>

        {step === 'resumo' ? (
          <>
            {loading && <div className="af-empty">Carregando histórico…</div>}

            {!loading && error && (
              <div className="af-last-card af-last-card--erro">
                <div className="af-empty">{error}</div>
                <button className="btn btn-ghost af-retry-btn" onClick={retry}>
                  Tentar novamente
                </button>
              </div>
            )}

            {!loading && !error && (
              <>
                <div className="af-actions">
                  <button
                    className="btn btn-ghost"
                    disabled={!temHistorico}
                    onClick={() => setStep('evolucao')}
                    title={temHistorico ? undefined : 'Registre a primeira avaliação para ver a evolução'}
                  >
                    Ver evolução
                  </button>
                  {!readOnly && canWrite && (
                    <button className="btn btn-primary" onClick={() => { setEditando(null); setStep('protocolo'); }}>
                      + Nova avaliação
                    </button>
                  )}
                  {podeEnviarOnline && !canWrite && (
                    <button className="btn btn-primary" onClick={() => setStep('online-form')}>
                      Fazer minha autoavaliação
                    </button>
                  )}
                </div>

                {podeComparar && (
                    <button
                    className="btn btn-ghost af-comparar-btn"
                    onClick={() => {
                      setModoComparar('primeira-atual');
                      setStep('comparar');
                    }}
                  >
                    ⇄ Comparar avaliações
                  </button>
                )}

                <AssessmentTimeline
                  assessments={assessments}
                  alunoId={alunoId}
                  canWrite={canWrite}
                  onRemover={remover}
                  onEditar={canWrite ? handleEditar : undefined}
                  onNovaAvaliacao={!readOnly && canWrite ? () => { setEditando(null); setStep('protocolo'); } : undefined}
                  onRevisar={
                    canWrite
                      ? (id) => {
                          setRevisandoId(id);
                          setStep('revisar-online');
                        }
                      : undefined
                  }
                />
              </>
            )}
          </>
        ) : (
          <div className="af-protocol-list">
            {PROTOCOL_OPTIONS.map((opt) => (
              <button
                key={opt.key}
                className={`af-protocol-card${opt.comingSoon ? ' af-protocol-card--soon' : ''}`}
                onClick={() => handleSelectProtocol(opt.key, opt.comingSoon)}
                disabled={opt.comingSoon}
              >
                <span className="af-protocol-icon" aria-hidden="true">{opt.icon}</span>
                <span className="af-protocol-text">
                  <span className="af-protocol-title">{opt.title}</span>
                  <span className="af-protocol-subtitle">{opt.subtitle}</span>
                </span>
                {opt.comingSoon ? (
                  <span className="af-protocol-badge">Em breve</span>
                ) : (
                  <span className="af-protocol-chevron" aria-hidden="true">›</span>
                )}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
